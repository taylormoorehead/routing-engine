/**
 * Demonstrates the calculation of shortest paths in the US Highway
 * network, showing the functionality of GraphProcessor and using
 * Visualize
 * To do: Add your name(s) as authors - Taylor Moorehead
 */

 import java.util.*;
 import java.io.*;
 
 public class GraphDemo {
 
     public static Map<String, Point> map = new HashMap<>();
     public static void main(String[] args) throws Exception {
         GraphProcessor gp = new GraphProcessor();
         FileInputStream file = new FileInputStream("data/usa.graph");
         gp.initialize(file);
         map = GraphDemo.readData("data/uscities.csv");
         Scanner scanner = new Scanner(System.in);
 
         System.out.printf("Enter the name of the city that you are starting at: ");
         String cityA = scanner.nextLine();
         System.out.println();
         System.out.println();
         Point a = map.get(cityA);
 
         System.out.printf("Enter the name of the city that you will end at: ");
         String cityB = scanner.nextLine();
         System.out.println();
         System.out.println();
         Point b = map.get(cityB);
 
         long start = System.nanoTime();
         Visualize v = new Visualize("data/usa.vis", "data/usa.png");
 
         Point c = gp.nearestPoint(a);
         System.out.println("The closest city to " + a.toString() + " is: " + c.toString());
         System.out.println();
 
         Point d = gp.nearestPoint(b);
         System.out.println("The closest city to " + b.toString() + " is: " + d.toString());
         System.out.println();
 
         double distance = gp.routeDistance(gp.route(a, b));
         v.drawRoute(gp.route(a, b));
         System.out.println("The route distance between the two cities is " + distance + " miles long!");
         System.out.println();
 
         long end = System.nanoTime() - start;
         System.out.println("It took " + end + "ms to find the nearest points, route, and get the route's distance.");
     }
 
     public static Map<String, Point> readData(String file) {
         Scanner scanner = new Scanner(file);
         map.clear();
         while(scanner.hasNextLine()) {
             try {
                 String s = scanner.nextLine();
                 String[] array = s.split(",");
                 map.putIfAbsent(array[0] + " " + array[1], new Point(Double.parseDouble(array[2]), Double.parseDouble(array[3])));
             } catch(Exception e) {
                 continue;
             }
         }
         return map;
     }
 }