import java.security.InvalidAlgorithmParameterException;
import java.io.FileInputStream;
import java.util.*;

/**
 * Models a weighted graph of latitude-longitude points
 * and supports various distance and routing operations.
 * To do: Add your name(s) as additional authors
 * @author Brandon Fain
 *
 */
public class GraphProcessor {
    
    private Map<Point, List<Point>> map = new HashMap<>();
    private List<Point> points = new ArrayList<>();
    private int vertices;
    private int edges;
    
    /**
     * Creates and initializes a graph from a source data
     * file in the .graph format. Should be called
     * before any other methods work.
     * @param file a FileInputStream of the .graph file
     * @throws Exception if file not found or error reading
     */
    public void initialize(FileInputStream file) throws Exception {
        map.clear();
        Scanner scanner = new Scanner(file);
        vertices = scanner.nextInt();
        edges = scanner.nextInt();
        scanner.nextLine();

        //for loop for lat/long
        for(int i = 0 ; i < vertices; i++) {
            String s = scanner.nextLine();
            String[] array = s.split(" ");
            points.add(new Point(Double.parseDouble(array[1]), Double.parseDouble(array[2])));
            map.putIfAbsent(points.get(i), new ArrayList<>());
        }

        //for loop for adj (key is the point, value all nodes adjacent - including the map)
        for(int i = 0; i < edges; i++) {
            String s = scanner.nextLine();
            String[] array = s.split(" ");
            map.get(points.get(Integer.parseInt(array[0]))).add(points.get(Integer.parseInt(array[1])));
            map.get(points.get(Integer.parseInt(array[1]))).add(points.get(Integer.parseInt(array[0])));
        }
    }


    /**
     * Searches for the point in the graph that is closest in
     * straight-line distance to the parameter point p
     * @param p A point, not necessarily in the graph
     * @return The closest point in the graph to p
     */
    public Point nearestPoint(Point p) {
        double distance = 1000000;
        Point answer = p;
        for(Point point : points) {
            if(point.distance(p) < distance && !(point.getLat() == p.getLat() && point.getLon() == p.getLon())) {
                distance = point.distance(p);
                answer = point;
            }
        }
        return answer;
    }


    /**
     * Calculates the total distance along the route, summing
     * the distance between the first and the second Points, 
     * the second and the third, ..., the second to last and
     * the last. Distance returned in miles.
     * @param start Beginning point. May or may not be in the graph.
     * @param end Destination point May or may not be in the graph.
     * @return The distance to get from start to end
     */
    public double routeDistance(List<Point> route) {
        double total = 0.0;
        for(int i = 1; i < route.size(); i++) {
            total += route.get(i - 1).distance(route.get(i));
        }
        return total;
    }
    

    /**
     * Checks if input points are part of a connected component
     * in the graph, that is, can one get from one to the other
     * only traversing edges in the graph
     * @param p1 one point
     * @param p2 another point
     * @return true if p2 is reachable from p1 (and vice versa)
     */
    public boolean connected(Point p1, Point p2) {
        if(!points.contains(p1) || !points.contains(p2)) {
            return false;
        }
        Stack<Point> stack = new Stack<>();
        stack.push(p1);
        Set<Point> visit = new HashSet<>();
        Point cur;
        while(!stack.isEmpty()) {
            cur = stack.pop();
            if(visit.contains(cur)) {
                continue;
            }
            visit.add(cur);
            Point[] adj = new Point[map.get(cur).size()];
            for(int i = 0; i < adj.length; i++) {
                adj[i] = map.get(cur).get(i);
            }
            for(int i = adj.length - 1; i >= 0; i--) {
                Point p = adj[i];
                if(!visit.contains(p)) {
                    stack.push(p);
                }
            }
            if(cur.equals(p2)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the shortest path, traversing the graph, that begins at start
     * and terminates at end, including start and end as the first and last
     * points in the returned list. If there is no such route, either because
     * start is not connected to end or because start equals end, throws an
     * exception.
     * @param start Beginning point.
     * @param end Destination point.
     * @return The shortest path [start, ..., end].
     * @throws InvalidAlgorithmParameterException if there is no such route, 
     * either because start is not connected to end or because start equals end.
     */
    public List<Point> route(Point start, Point end) throws InvalidAlgorithmParameterException {
        Map<Point, Double> distances = new HashMap<>();
        PriorityQueue<Point> v = new PriorityQueue<>((a, b) -> Double.compare(distances.get(a), distances.get(b)));
        Map<Point, Point> path = new HashMap<>();
        distances.put(start, 0.0);
        v.add(start);
        while(!v.isEmpty()) {
            Point cur = v.remove();
            for(Point p : map.get(cur)) {
                double dist = cur.distance(p) + distances.get(cur);
                if(!distances.containsKey(p) || dist + 0.1 < distances.get(p)) {
                    distances.put(p, dist);
                    path.put(p, cur);
                    v.add(p);
                }
            }
        }
        List<Point> answer = new ArrayList<>();
        answer.add(end);
        Point point = path.get(end);
        while(!point.equals(start)) {
            answer.add(point);
            point = path.get(point);
        }
        answer.add(start);
        Collections.reverse(answer);
        return answer;
    }

    
}
